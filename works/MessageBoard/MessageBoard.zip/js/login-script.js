$(function(){
    ModulePackage.styleModule.loginStyle();
    ModulePackage.regexModule.loginReg();
});